package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService {

	ContactBookDao dao = new ContactBookDaoImpl();
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException {

		List<String> list = new ArrayList();
		boolean result = false;
		
		if (!validateFirstName(enqry.getfName())) {
               list.add("firstName should Have min 5 characters and less than 20 characters");
		}
		if (!validateLastName(enqry.getlName())) {
			 list.add("lastName should Have min 5 characters and less than 20 characters");
		}
		if(!validateContactNo(enqry.getContactNo())) {
			list.add("contactNo should contain only 10 digits");
		}
		if(!validatePDomain(enqry.getpDomain())) {
			list.add("PDomain cann't be blank");
		}
		if(!validatePLocation(enqry.getpDomain())) {
			list.add("PLocation cann't be blank");
		}
		if (!list.isEmpty()) {
			result = false;
			throw new ContactBookException(list + "");
		} else {
			result = true;//if list is empty
		}
		return result;
		
	}
     public boolean validatePLocation(String pLocation) {
    	 String pLocationRegEx = "[A-Za-z]{1,}";
 		Pattern pattern = Pattern.compile(pLocationRegEx);
 		Matcher matcher = pattern.matcher(pLocation);
 		return matcher.matches();
     }
     public boolean validatePDomain(String pDomain) {
		String pDomainRegEx = "[A-Za-z]{1,}";
		Pattern pattern = Pattern.compile(pDomainRegEx);
		Matcher matcher = pattern.matcher(pDomain);
		return matcher.matches();
		
	}

	public boolean validateContactNo(String contactNo) {
		
		String contactNoRegEx = "[6-9]{1}[0-9]{9}";
		Pattern pattern = Pattern.compile(contactNoRegEx);
		Matcher matcher = pattern.matcher(contactNo);
		return matcher.matches();
		
	}

	public  boolean validateLastName(String lName) {
		String lNameRegEx = "[A-Z]{1}[a-zA-Z]{4,19}";
		Pattern pattern = Pattern.compile(lNameRegEx);
		Matcher matcher = pattern.matcher(lName);
		return matcher.matches();
		
	}

	public boolean validateFirstName(String fName) {
		String fNameRegEx = "[A-Z]{1}[a-zA-Z]{4,19}";
		Pattern pattern = Pattern.compile(fNameRegEx);
		Matcher matcher = pattern.matcher(fName);
		return matcher.matches();
	}
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		return dao.addEnquiry(enqry);
	}
	@Override
	public EnquiryBean getEnquiryDetails(int enqryId) throws ContactBookException {
		return dao.getEnquiryDetails(enqryId);
	}

}
