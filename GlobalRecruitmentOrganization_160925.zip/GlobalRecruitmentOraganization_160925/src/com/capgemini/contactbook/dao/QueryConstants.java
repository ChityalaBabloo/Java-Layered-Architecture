package com.capgemini.contactbook.dao;

public interface QueryConstants {
	
	public static final String insertQuery = "INSERT into enquiry VALUES(enquiries.nextval,?,?,?,?,?)";
	public static final String getIdQuery = "SELECT max(enqryid) from enquiry";
	public static final String getDetails = "SELECT * from enquiry where enqryid=?";

}
